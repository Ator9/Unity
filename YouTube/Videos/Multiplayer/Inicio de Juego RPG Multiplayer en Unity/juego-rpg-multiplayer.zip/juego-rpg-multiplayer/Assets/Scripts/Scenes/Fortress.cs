using UnityEngine;

public class Fortress : MonoBehaviour
{
    [SerializeField] Camera sceneCamera;
    [SerializeField] GameObject playerPrefab;

    private void Awake()
    {
        sceneCamera.enabled = false;
    }

    void Start()
    {
        GameObject spawn = Instantiate(playerPrefab, new Vector3(Random.Range(1, 60), 1f, Random.Range(1, 60)), playerPrefab.transform.rotation);
    }
}
