public static class CharacterStats
{
    public const int HEALTH = 100;
    public const int ENERGY = 100;
    public const int JUMP_FORCE = 5;

    public const int SPEED = 100;
    public const float BACKWARDS_SPEED_MULTIPLIER = 0.3f;
}
