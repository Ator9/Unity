using System;
using UnityEngine;

public class Player : MonoBehaviour
{
    public GameObject camPrefab;

    private void Awake()
    {
        GameManager.GameState[] array = { GameManager.GameState.EditorMode, GameManager.GameState.Fortress };
        if (Array.IndexOf(array, GameManager.CurrentGameState) > -1)
        {
            this.GetComponent<AudioListener>().enabled = true; // 1 audio per scene
            this.GetComponent<InputManager>().enabled = true; // 1 input per scene (to avoid the use of IsLocalPlayer check)
            Instantiate(camPrefab, transform); // Attach Camera
        }
    }

    private void Update()
    {
        Debug.DrawRay(transform.position, transform.forward * 10, Color.red);
    }
}
