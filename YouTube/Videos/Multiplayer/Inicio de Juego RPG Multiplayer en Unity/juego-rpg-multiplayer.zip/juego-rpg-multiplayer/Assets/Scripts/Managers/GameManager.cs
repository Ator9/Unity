using UnityEngine;
using Unity.Netcode;
using UnityEngine.SceneManagement;

public class GameManager : Singleton<GameManager>
{
    public enum GameState { EditorMode, MainMenu, Fortress, OpenWorld,  }
    private static GameState _currentGameState = GameState.EditorMode;

    public static GameState CurrentGameState { get { return _currentGameState; } }

    private static AudioListener audioListener;

    protected override void Awake()
    {
        base.Awake();
        audioListener = Camera.main.GetComponent<AudioListener>();
    }

    private void OnEnable()
    {
        audioListener.enabled = true; // fixes temp "There are 2 audio listeners in the scene"
    }

    public static void sceneLoader(string scene, string type = "solo")
    {
        if (SceneManager.GetActiveScene().name != scene)
        {
            switch (scene)
            {
                case "Boot":
                    _currentGameState = GameState.MainMenu;
                    break;

                case "Fortress":
                    _currentGameState = GameState.Fortress;
                    break;

                case "OpenWorld":
                    audioListener.enabled = false; // fixes temp "There are 2 audio listeners in the scene"
                    _currentGameState = GameState.OpenWorld;

                    if(type == "host" || type == "server")
                    {
                        if(type == "host") NetworkManager.Singleton.StartHost();
                        else if(type == "server") NetworkManager.Singleton.StartServer();

                        NetworkManager.Singleton.SceneManager.LoadScene(scene, LoadSceneMode.Single);
                    }
                    else NetworkManager.Singleton.StartClient();

                    return; // forced break
            }

            SceneManager.LoadScene(scene);
        }
    }

    public void JoinFortress()
    {
        sceneLoader("Fortress");
    }

    public void JoinOpenWorld()
    {
        sceneLoader("OpenWorld");
    }

    public void HostOpenWorld()
    {
        sceneLoader("OpenWorld", "host");
    }

    public void ServerOpenWorld()
    {
        sceneLoader("OpenWorld", "server");
    }

    public static void Disconnect()
    {
        NetworkManager.Singleton.Shutdown();
        Destroy(NetworkManager.Singleton.gameObject); // fixes duplicated "NetworkManager" objects start/stop

        sceneLoader("Boot");
    }

    public void QuitGame()
    {
        Application.Quit();
    }
}
