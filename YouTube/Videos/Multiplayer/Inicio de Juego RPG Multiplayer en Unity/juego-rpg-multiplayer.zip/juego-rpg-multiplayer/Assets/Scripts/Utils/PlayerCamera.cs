using UnityEngine;
using UnityEngine.InputSystem;

// Original: https://answers.unity.com/questions/1489636/third-person-wow-like-camera.html

public class PlayerCamera : MonoBehaviour
{
    private float distance = 10.0f;
    private float targetHeight = 2f;

    private float maxDistance = 20;
    private float minDistance = .6f;

    private float offsetFromWall = 0.1f;

    private int yMinLimit = -40;
    private int yMaxLimit = 80;

    private float zoomDampening = 5.0f;

    private LayerMask collisionLayers = -1;
    private Vector3 vTargetOffset;

    private float xDeg, yDeg = 0.0f;
    private float currentDistance, desiredDistance, correctedDistance;

    void Start()
    {
        currentDistance = desiredDistance = correctedDistance = distance;

        // Make the rigid body not change rotation
        if (this.gameObject.GetComponent<Rigidbody>())
            this.gameObject.GetComponent<Rigidbody>().freezeRotation = true;
    }

    void LateUpdate()
    {
        // If either mouse buttons are down, let the mouse govern camera position
        if (GUIUtility.hotControl == 0)
        {
            if (Mouse.current.leftButton.isPressed || Mouse.current.rightButton.isPressed)
            {
                xDeg += Mouse.current.delta.ReadValue().x * 0.2f;
                yDeg -= Mouse.current.delta.ReadValue().y * 0.1f;

                if(Mouse.current.rightButton.isPressed) transform.parent.transform.rotation = Quaternion.Euler(0, xDeg, 0);
            }
        }

        // Zoom: calculate the desired distance
        desiredDistance -= Mouse.current.scroll.ReadValue().y * Time.deltaTime * Mathf.Abs(desiredDistance) * 0.5f;
        desiredDistance = Mathf.Clamp(desiredDistance, minDistance, maxDistance);

        yDeg = ClampAngle(yDeg, yMinLimit, yMaxLimit);

        // set camera rotation
        Quaternion rotation = Quaternion.Euler(yDeg, xDeg, 0);
        correctedDistance = desiredDistance;

        // calculate desired camera position
        vTargetOffset = new Vector3(0, -targetHeight, 0);
        Vector3 position = transform.parent.position - (rotation * Vector3.forward * desiredDistance + vTargetOffset);

        // check for collision using the true target's desired registration point as set by user using height
        RaycastHit collisionHit;
        Vector3 trueTargetPosition = new Vector3(transform.parent.position.x, transform.parent.position.y, transform.parent.position.z) - vTargetOffset;

        // if there was a collision, correct the camera position and calculate the corrected distance
        bool isCorrected = false;
        if (Physics.Linecast(trueTargetPosition, position, out collisionHit, collisionLayers.value))
        {
            // calculate the distance from the original estimated position to the collision location,
            // subtracting out a safety "offset" distance from the object we hit.  The offset will help
            // keep the camera from being right on top of the surface we hit, which usually shows up as
            // the surface geometry getting partially clipped by the camera's front clipping plane.
            correctedDistance = Vector3.Distance(trueTargetPosition, collisionHit.point) - offsetFromWall;
            isCorrected = true;
        }

        // For smoothing, lerp distance only if either distance wasn't corrected, or correctedDistance is more than currentDistance
        currentDistance = !isCorrected || correctedDistance > currentDistance ? Mathf.Lerp(currentDistance, correctedDistance, Time.deltaTime * zoomDampening) : correctedDistance;

        // keep within legal limits
        currentDistance = Mathf.Clamp(currentDistance, minDistance, maxDistance);

        // recalculate position based on the new currentDistance
        position = transform.parent.position - (rotation * Vector3.forward * currentDistance + vTargetOffset);

        transform.rotation = rotation;
        transform.position = position;
    }

    private static float ClampAngle(float angle, float min, float max)
    {
        if (angle < -360) angle += 360;
        if (angle > 360) angle -= 360;

        return Mathf.Clamp(angle, min, max);
    }
}