using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.EventSystems;

public class InputManager : MonoBehaviour
{
    private Rigidbody playerRb;
    private PlayerInputActions playerInputActions;
    private PlayerNetwork playerNetwork;

    private Vector2 movementForce;
    private bool isGrounded;
    private float speedMultiplier;

    private void Awake()
    {
        playerRb = this.GetComponent<Rigidbody>();
        playerNetwork = this.GetComponent<PlayerNetwork>();
        playerInputActions = new PlayerInputActions();
    }

    // Update is called once per frame
    void Update()
    {
        movementForce = playerInputActions.Player.Movement.ReadValue<Vector2>(); // WASD

        if(Mouse.current.leftButton.isPressed && Mouse.current.rightButton.isPressed && movementForce.y == 0)
            movementForce = new Vector2(movementForce.x, 1).normalized;

        if (Mouse.current.leftButton.wasPressedThisFrame) print("left mouse");

        if (Keyboard.current.mKey.wasPressedThisFrame) // isPressed
        {
            print("move");
            playerNetwork.Move2();
        }
    }

    // FixedUpdate executes 50 times per second
    void FixedUpdate()
    {
        if (isGrounded) Move(); // WASD
    }

    public void Jump(InputAction.CallbackContext obj)
    {
        if (isGrounded)
        {
            playerRb.AddForce(Vector3.up * CharacterStats.JUMP_FORCE, ForceMode.Impulse);
            isGrounded = false; // fix in place jump (velocity zero)
        }
    }

    public void Move()
    {
        if (movementForce != Vector2.zero)
        {
            // Slower backwards walking:
            speedMultiplier = (movementForce.y < 0) ? CharacterStats.BACKWARDS_SPEED_MULTIPLIER : 1;

            // Run (Shift)
            //if (Input.GetKey(KeyCode.LeftShift) || Input.GetKey(KeyCode.RightShift))
            //{
            //    moveDirection *= 1.3f;
            //    if (!playerAudio.isPlaying) playerAudio.PlayOneShot(runSound, 0.5f);

                //    anim.SetFloat("speed", 1.3f);
                //}
                //else // Walk
                //{ 
                //    if (!playerAudio.isPlaying) playerAudio.PlayOneShot(walkSound, 0.3f);

                //    anim.SetFloat("speed", 1);
                //}


            playerRb.AddRelativeForce(new Vector3(movementForce.x, 0, movementForce.y) * speedMultiplier * 200);
            playerRb.velocity = Vector3.ClampMagnitude(playerRb.velocity, CharacterStats.SPEED * speedMultiplier / 10);

            //if (playerNetwork) playerNetwork.Move(playerRb.position);
        }
        else if (playerRb.velocity != Vector3.zero)
        {
            playerRb.velocity = Vector3.zero;
        }
    }

    // This function is called when the object becomes enabled and active.
    private void OnEnable()
    {
        playerInputActions.Enable(); // Enable all actions maps or enable specific action map
        playerInputActions.Player.Escape.started += Escape; // started = one time
        playerInputActions.Player.Jump.started += Jump;
    }

    private void OnDisable()
    {
        playerInputActions.Disable();
    }

    public void Escape(InputAction.CallbackContext obj)
    {
        GameManager.Disconnect();
    }

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.collider.tag == "Terrain") isGrounded = true;
    }

    private void OnCollisionExit(Collision collision)
    {
        if (collision.collider.tag == "Terrain") isGrounded = false;
    }

    private bool IsPointingUi()
    {
        return EventSystem.current.IsPointerOverGameObject(); // Raycast target ON to ignore ui (hotbar, inventory)
    }
}
