//------------------------------------------------------------------------------
// @author DevSeba
// https://www.youtube.com/channel/UCf7zkU3ITDaiGk0rYStub3w
//------------------------------------------------------------------------------
using System.Text.RegularExpressions;
using System;

namespace DevSeba
{
    public class Utils
    {
        public static int GetNumberFromString(string text)
        {
            return Int32.Parse(Regex.Replace(text, "[^0-9]", ""));
        }
    }

    public static class RandomEnum<T>
    {
        static readonly T[] m_Values;
        static RandomEnum()
        {
            var values = System.Enum.GetValues(typeof(T));
            m_Values = new T[values.Length];
            for (int i = 0; i < m_Values.Length; i++)
                m_Values[i] = (T)values.GetValue(i);
        }
        public static T Get()
        {
            return m_Values[UnityEngine.Random.Range(0, m_Values.Length)];
        }
    }
}

