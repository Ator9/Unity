using UnityEngine;
using Unity.Netcode;

public class PlayerNetwork : NetworkBehaviour
{
    // Called by all previous objects, and new ones 1 by 1
    public override void OnNetworkSpawn()
    {
        if (IsLocalPlayer) // if (IsOwner) Move2();
        {
            transform.position = new Vector3(1, 1, 1);

            this.GetComponent<AudioListener>().enabled = true; // 1 audio per scene
            this.GetComponent<InputManager>().enabled = true; // 1 input per scene (to avoid the use of IsLocalPlayer check)
            Instantiate(this.GetComponent<Player>().camPrefab, transform); // Attach Camera
        }
    }

    public void Move2()
    {
        transform.position = new Vector3(Random.Range(1f, 3f), 1f, Random.Range(1f, 3f));
    }
}
