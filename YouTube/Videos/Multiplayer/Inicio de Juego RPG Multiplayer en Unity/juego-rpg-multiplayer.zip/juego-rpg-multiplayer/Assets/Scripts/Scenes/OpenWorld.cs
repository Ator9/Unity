using UnityEngine;

public class OpenWorld : MonoBehaviour
{
    [SerializeField] Camera sceneCamera;
    [SerializeField] GameObject playerPrefab;

    private void Awake()
    {
        sceneCamera.enabled = false;
    }

    void Start()
    {
        // Spawn player if not in network (editor test):
        if(GameManager.CurrentGameState == GameManager.GameState.EditorMode)
        {
            GameObject player = Instantiate(playerPrefab, new Vector3(Random.Range(1, 60), 1f, Random.Range(1, 60)), playerPrefab.transform.rotation);
        }
    }
}
