using UnityEngine;
using Unity.Netcode;

public class PlayerNetwork_old : NetworkBehaviour
{
    public NetworkVariable<Vector3> Position = new NetworkVariable<Vector3>();

    // Called by all previous objects, and new ones 1 by 1
    public override void OnNetworkSpawn()
    {
        if (IsLocalPlayer) // if (IsOwner) Move2();
        {
            transform.position = new Vector3(1, 1, 1);
            SubmitPositionRequestServerRpc(transform.position);

            this.GetComponent<AudioListener>().enabled = true; // 1 audio per scene
            this.GetComponent<InputManager>().enabled = true; // 1 input per scene (to avoid the use of IsLocalPlayer check)
            Instantiate(this.GetComponent<Player>().camPrefab, this.transform); // Attach Camera
        }
    }

    public void Move(Vector3 pos)
    {
        if (NetworkManager.Singleton.IsServer)
        {
            transform.position = pos;
            Position.Value = pos;
        }
        else SubmitPositionRequestServerRpc(pos);
    }

    [ServerRpc]
    void SubmitPositionRequestServerRpc(Vector3 pos)
    {
        Position.Value = pos;
    }

    public void Move2()
    {
        Move2ServerRpc();
    }

    [ServerRpc]
    void Move2ServerRpc(ServerRpcParams rpcParams = default)
    {
        Position.Value = new Vector3(Random.Range(1f, 3f), 1f, Random.Range(1f, 3f));
    }

    void Update()
    {
        transform.position = Position.Value;
    }
}
